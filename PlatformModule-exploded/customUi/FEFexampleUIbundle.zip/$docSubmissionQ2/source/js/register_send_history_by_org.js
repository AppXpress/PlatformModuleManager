/**
 * Send History by Org - a section composed of:
 * 
 * 1. historyListByOrg - a virtual field on $docSubmissionQ2 that produces a version of historyList grouped by org.
 * 2. historyListByOrgTable - the table backed by historyListByOrg
 * 3. historyListSelectedOrgTable - the detail table for an org selected in historyListByOrgTable; backed by historyList and filtered by the selected org
 * 4. latestVersionForOrg, etc. - virtual fields on $historyEntryQ1 displayed in historyListByOrgTable
 */
// a) historyListByOrg table is backed by a virtual field on $docSubmissionQ2
var byOrgCache = {}; // cache used by historyListByOrg
Facade.VirtualFieldRegistry.register("$docSubmissionQ2","historyListByOrg",function(pathContext){
	// get the real data
	var data = pathContext.getData();
	var historyList = data.historyList;
	
	// 1) byOrg
	var byOrg = [];
	var i, orgEntries, org, orgEntry, cacheEntry;
	if (historyList && historyList.length) {
		orgEntries = {}; // map orgid to an entry in historyList
		for (i = 0; i < historyList.length; i++) {
			var historyListSentToOrg = pathContext.getData("historyList[" + i + "].sentToOrg");
			if (historyListSentToOrg) {
				org = historyListSentToOrg.getOrganizationId();
				if (org) {
					orgEntry = orgEntries[org];
					if (!orgEntry) {
						// We first try to get an entry from byOrgCache.  The pupose of this cache is to avoid reconstructing a row object each call.
						// This reconstruction results in the row's $node being destroyed and this we immediately lose the seleciton-set record upon selection.
						cacheEntry = byOrgCache[org];
						if (!cacheEntry) {
							cacheEntry = byOrgCache[org] = {};
						}
						orgEntry = orgEntries[org] = cacheEntry;
						byOrg.push(orgEntry);
						orgEntry.sentToOrg = historyListSentToOrg.getObject();
					}
				}
			}
		}
	}
	
	return byOrg;
});
// b) make the selector buttons always visible (by default its only visible in edit mode)
var historyListByOrgTable = Facade.Components.Table.forName("historyListByOrgTable");
historyListByOrgTable.defaultSelection().setMask("NORMAL");
// c) historyListSelectedOrgTable - the table representing the detail rows for the selected org
var historyListSelectedOrgTable = Facade.Components.Table.forName("historyListSelectedOrgTable");
historyListSelectedOrgTable.setFilter(function(behaviorFn,filterArgs){
	var rowOrg = filterArgs.getPathContext().getData("sentToOrg");
    var selectedPath = behaviorFn.components.detail.getSelectionSet().getPaths()[0];
    var selectedRowSentToOrg = Facade.PageRegistry.getPrimaryData().getData(selectedPath+".sentToOrg")
    return rowOrg && selectedRowSentToOrg && rowOrg.getOrganizationId() == selectedRowSentToOrg.getOrganizationId();

});
// d) helper function - get latest history entry for the given org
function getLatestHistoryEntryByOrg(org) {
	var historyList = Facade.PageRegistry.getPrimaryData().getData("historyList");
	var latestVersion = undefined;
	var latestEntry = undefined;
	var orgId, i, version;
	if (historyList && org && (orgId = org.getOrganizationId())) {
		for (i = 0; i < historyList.length; i++) {
			var historyListSentToOrg = Facade.PageRegistry.getPrimaryData().getData("historyList[" + i + "].sentToOrg");
			if (historyListSentToOrg && historyListSentToOrg.getOrganizationId() == orgId) {
				version = historyList[i].documentVersion;
				if (!latestVersion || parseInt(latestVersion) < parseInt(version)) {
					latestVersion = version;
					latestEntry = historyList[i];
				}
			}
		}
	}
	return latestEntry;
}
//e) latest version - a virtual field on $historyEntryQ1 representing the latest version for the org
Facade.VirtualFieldRegistry.register("$historyEntryQ1","latestVersionForOrg",function(pathContext){
	var latestEntry = getLatestHistoryEntryByOrg(pathContext.getData("sentToOrg"));
	return latestEntry.documentVersion;
});
//f) latest ack
Facade.VirtualFieldRegistry.register("$historyEntryQ1","latestReqAcknowledgementForOrg",function(pathContext){
	var latestEntry = getLatestHistoryEntryByOrg(pathContext.getData("sentToOrg"));
	return latestEntry.reqAcknowledgement;
});
//g) latest sent user
Facade.VirtualFieldRegistry.register("$historyEntryQ1","latestSentByUserForOrg",function(pathContext){
	var latestEntry = getLatestHistoryEntryByOrg(pathContext.getData("sentToOrg"));
	return latestEntry.sentByUser;
});
//h) latest sent date
Facade.VirtualFieldRegistry.register("$historyEntryQ1","latestSendDateTimeForOrg",function(pathContext){
	var latestEntry = getLatestHistoryEntryByOrg(pathContext.getData("sentToOrg"));
	return latestEntry.sendDateTime;
});
