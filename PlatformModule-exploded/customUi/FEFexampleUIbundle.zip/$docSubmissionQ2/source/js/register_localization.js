/**
 * Localization Keys.  This is a temporary solution until we offer server-side localization.
 */
var localizationKeys = {
	"memberAlreadyInReviewList": "Member already in review list: ",
	"membersAlreadyInReviewList": "Member(s) already in review list: ",
	"listHasNoMembers": "The selected seller list has no members.",
	"docSubmissionTitle":"Document Submission for",
	"lookup.add": "Add",
	"campaignSection": "Document Identification",
	"attachmentsSection": "Documents",
	"membersToReviewSection": "Members to Review Document",
	"sendHistorySection": "Send History",
	"sendHistoryByOrgTab": "By Org",
	"sendHistoryByVersionTab": "By Version",
	"sendHistoryFullTab": "Full History",
	"orgLookup.label": "Add member",
	"sellerGroupLookup.label": "Add seller group",
	"sellerGroupLookup.reloadData": "Reload Seller Groups",
	"sellerGroupLookup.sellerGroupPicklistDropdown.selectSeller": "Select a seller group",
	"reviewList.sellerParty": "Member Party",
	"historyListByOrg.latestVersionForOrg": "Latest Version",
	"historyListByOrg.latestReqAcknowledgementForOrg": "Latest Version Need Ack",
	"historyListByOrg.latestSentByUserForOrg": "Latest Sent by",
	"historyListByOrg.latestSendDateTimeForOrg": "Latest Sent Date",
	"historyListByVersion.latestSendDateTimeForVersion": "Latest Sent Date",
	"campaign": "Campaign",
    "noLicensees": "Module has no licensee",
    "cannotCreate": "Cannot create a campaign.",
    "chooseLicenseeSection": "Choose a Licensee",
    "licenseeLookup.label": "Which organization?",
	"status.InReEditMode": "Pending",
	"status.ReviewComplete": "Review Complete",
	"status.InReview": "Waiting Supplier Acknowledgment",
	"status.New":"Not Submitted",
	"localizedStatus": "Status",
	"docCategoryLabel": "Document Category",
	"historyList.docCategoryLabel": "Document Category",
	"addvendors": "Add Vendors"
	
	
};
Facade.FunctionRegistry.register("core.localization.localize",function(behaviorFn,args){
	var s = localizationKeys[args.key];
	if (s != undefined) {
		return s;
	} else {
		return behaviorFn.resume();
	}
});
