/**
 * orgLookup - a named customization of the built-in core-party-lookup.
 * 
 * core-party-lookup at a minimum needs a lookup callback to react to the user action.
 * In our case, we add the selections to the document submission's reviewList.
 * We also highlight already-selected parties in the lookup window and dont allow duplicate selection of them.
 */
// lookup callback
Facade.FunctionRegistry.register("onPartyLookup",function(behaviorFn,args) {
	var parties = behaviorFn.components.partyLookup.getSelectionSet().getSelections();
	var docSub = Facade.PageRegistry.getPrimaryData();
	var i, newMember;
    var dropdown = behaviorFn.components.partyLookup.getDropdown();
	for (i = 0; i < parties.length; i++) {
		// check if already exists
		if (Facade.FunctionRegistry.evaluate("isInReviewList",parties[i])) {
			alert(Facade.Localization.localize("memberAlreadyInReviewList") + parties[i].getName());
		} else {
			newMember = Facade.DataRegistry.createEmbedded({type: "$sellerData2Q2"});
			newMember.sellerOrgID = parties[i].getOrganizationId();
			newMember.sellerParty = parties[i].duplicate();
			docSub.pushData("reviewList",newMember);
            dropdown.setSelectedItem(undefined);
		}
	}
});

var orgLookup = Facade.Components.PartyLookup.forName("orgLookup");
orgLookup.setOnLookupFunction("onPartyLookup");

orgLookup.setFilter(function(behaviorFn,filterArgs){
	var roles = filterArgs.data.getRoles();
	return roles && roles.indexOf("Seller") != -1;
})

orgLookup.lookupTable().setFilter(function(behaviorFn,filterArgs){
	var roles = filterArgs.data.getRoles();
	return roles && roles.indexOf("Seller") != -1;
});

// this function is used below to determine membership of a party in reviewList
Facade.FunctionRegistry.register("isInReviewList",function(behaviorFn,party) {
	var reviewList = Facade.PageRegistry.getPrimaryData().getData("reviewList");
	var i, sellerParty;
	if (reviewList) {
		for (i = 0; i < reviewList.length; i++) {
			sellerParty = Facade.PageRegistry.getPrimaryData().getData("reviewList[" + i + "].sellerParty");;
			if (sellerParty && party.getOrganizationId() == sellerParty.getOrganizationId()) {
				return true;
			}
		}
	}
})
// highlight the rows and disable selection for orgs already added
Facade.FunctionRegistry.register("getPartyTableRowClass",function(behaviorFn,args){
	if (Facade.FunctionRegistry.evaluate("isInReviewList",behaviorFn.components.tableRow.getPathContext().getData())) {
		return behaviorFn.resume() + " highlighted";
	} else {
		return behaviorFn.resume();
	}
})
orgLookup.lookupTable().row().setTableRowClassFunction("getPartyTableRowClass");
Facade.FunctionRegistry.register("getPartyIsSelectable",function(behaviorFn,args){
	if (Facade.FunctionRegistry.evaluate("isInReviewList",behaviorFn.components.tableRow.getPathContext().getData())) {
		return false;
	} else {
		return behaviorFn.resume();
	}
})
orgLookup.lookupTableMultipleSelection().setIsSelectableFunction("getPartyIsSelectable");
// select button label
orgLookup.selectButton().setLabelKey("lookup.add");
