/**
 * Onload - operations that take place when the app first loads
 */

/**
 * Note about auto-save:
 * 
 * We auto-save the document submission on create.
 * By default, objects are not saved until the user clicks Save in the docbar.
 * We instead save immediately at page load.
 * By returning the promise produced by the save call to the core.app.onLoad trigger, 
 * the UI is effectively halted from interaction until it completes.
 * 
 * Only in the case where there are multiple licensees do we not auto-save.
 */

 
/**
 * dropdown for document categories from table or from reference table / pick list
**/
Facade.Resolver.query("$tableForPicklistL1", { params: {oql:"tableName = 'Document Category Picklist'"}, slotName: "myDocCategoryForPicklistSlot"});

Facade.Components.Field.forName("documentCategory").picklist().setPicklist(function(behaviorFn, args) {
    var dataFromObject = Facade.DataRegistry.get("myDocCategoryForPicklistSlot");
	//console.log(dataFromObject.getData());
    if (dataFromObject.getData().length == 0) {
	    return behaviorFn.resume();
	}
	var arrayOfobjectsForPickList = dataFromObject.getData("0.listEntry");
    var entries = [];
    for (var i = 0; i < arrayOfobjectsForPickList.length; i++) {
        entries.push({ value: arrayOfobjectsForPickList[i].code, label: arrayOfobjectsForPickList[i].description});
    }
    return Facade.PicklistRegistry.create(entries);
})

/**
 * initialSaveInProgress - a flag we use to track whether we are saving the doc for the first time.
 * 
 * It's usefulness is apparent below when we intercept onSaveSuccess and disable the ui success message in this case.
 */
var initialSaveInProgress = false;


/**
 * Helper method - getLicensees - the available licensees for the document.
 */
function getLicensees() {
    var design = Facade.DesignRegistry.get("$docSubmissionQ2");
    if ( design ) {
        return design.getData("licensee.orgId");
    }
    return [];
}

Facade.FunctionRegistry.register("core.page.onTransitionSuccess",function(behaviorFn,args) {
		if ( args.action === "wf_createNewVersion" ) {
			initDocuments(args.data);
        }
		//console.log(args.action);
		if ( args.action != "wf_addVendors" && args.action != "wf_addvendors" ) {
		   // any other post-transition stuff you want to do
		   //console.log("in here");
		   behaviorFn.resume(); // to preserve that default info alert message
		}
    });


var documents = Facade.Components.Attachments.forKind("repositoryAttachments");
var repoId;
function initDocuments(docSubmission) {
    repoId = docSubmission.data.linkToAttachments.rootId;
    docSubmission.getData("linkToAttachments"); // force doc repo to load
    // get repo's attachments
    Facade.Resolver.queryAttachments("$doucmentRepositoryF1", repoId).then(function(attachments) {
        Facade.DataRegistry.register("repositoryAttachments", attachments);
    });
};

documents.setAnchor(function(behaviorFn, args) {
    return Facade.DataRegistry.get("$doucmentRepositoryF1." + repoId);
})
documents.setDataIndex("repositoryAttachments"); // point attachments to repositoryAttachments data slot
documents.table().setLabelVisible("false");

documents.setMask(function(behaviorFn,args){
    var docSubmissionStatus = Facade.PageRegistry.getPrimaryData().getData("status");
	if (docSubmissionStatus == "addingToReviewList" ) {
		return "HIDDEN";
	}
   return behaviorFn.resume();
});

documents.addButton().setMask(function(behaviorFn, args) {
	var docSubmissionStatus = Facade.PageRegistry.getPrimaryData().getData("status");
	if (docSubmissionStatus == "addingToReviewList" ) {
		return "HIDDEN";
	}
   return behaviorFn.resume();
})
documents.removeButton().setMask(function(behaviorFn, args) {
	var docSubmissionStatus = Facade.PageRegistry.getPrimaryData().getData("status");
	if (docSubmissionStatus == "addingToReviewList" ) {
		return "HIDDEN";
	}
   return behaviorFn.resume();
});


/**
 * Helper method - setDocSubmissionLicensee - assign the given licensee to the document and save it; then forward to the main screen.
 */
function setDocSubmissionLicensee(licensee) {
    var doc = Facade.PageRegistry.getPrimaryData();
    doc.setData("buyerLicensee", {
        memberId: licensee
    });
    initialSaveInProgress = true;
    return Facade.PageRegistry.save().then(function(){
        var docSubmission = Facade.PageRegistry.getPrimaryData();
        initialSaveInProgress = false;
        Facade.PageRegistry.setCurrent("DocumentSubmission")
        initDocuments(docSubmission);
    });
};


/**
 * Define startingPage.
 * The first page of the app should be the LicenseePicker if the doc is new and more than one choice is available.
 */
Facade.FunctionRegistry.register("core.page.startingPage",function(behaviorFn, args) {
	var doc = Facade.PageRegistry.getPrimaryData(),
    	licensees = getLicensees();
	if (doc.isNew && licensees && licensees.length > 1) {
		return Facade.PageRegistry.get("LicenseePicker");
	}
	return behaviorFn.resume();
});


/**
 * On app load, inspect the licensees available if this is a new doc:
 * 1. if we find there are no licensees available, report an error condition.
 * 2. if there is one available, assign it
 * 3. if there is more than one available, take no action: above the starting page will be set in this condition.
 * 
 * In case 2, we return the promise for the save operation.  The result is that the UI will not load until that completes.
 */
Facade.TriggerRegistry.register("core.app.onLoad",function() {
	var doc = Facade.PageRegistry.getPrimaryData(),
        licensees = getLicensees();

	if (doc.isNew) {
        if ( !licensees || !licensees.length ) {
            Facade.MessageLog.addEntry("noLicensees");
            Facade.MessageLog.addMessage(Facade.MessageLog.createError("cannotCreate"));
        } else if (licensees.length === 1) { // just set buyer licensee to one licensee available and save
            return setDocSubmissionLicensee(licensees[0]);
        }
	} else {
        initDocuments(doc);
    }
});


/**
 * Licensee Org Lookup - when user makes a selection, set the licensee on the doc.
 */
Facade.FunctionRegistry.register("onLicenseeSelected",function(behaviorFn,args){
	// upon selection, set the document's licensee and forward to the main page
	var selectedOrg = behaviorFn.components.lookup.getSelectionSet().getSelections()[0];
	setDocSubmissionLicensee(Facade.Decorator.Organization(selectedOrg).getOrganizationId());
})


/**
 * We want to suppress the "Saved successfully" alert when the page first loads with a newly created object (see core.page.onLoad above)
 */
Facade.FunctionRegistry.register("core.page.onSaveSuccess",function(behaviorFn,args) {
	if (!initialSaveInProgress) {
		behaviorFn.resume();
	} else {
        initDocuments(args.data);
    }
});

Facade.Components.Docbar.editButton().setMask(function(behaviorFn,args){
    var docSubmissionStatus = Facade.PageRegistry.getPrimaryData().getData("status");
	if (docSubmissionStatus == "InReview" || docSubmissionStatus == "ReviewComplete" ) {
		return "HIDDEN";
	}
	return Facade.PageRegistry.inEditMode() ? "HIDDEN" : "NORMAL"
});


/**
 * On app load:
 * 1. create new embedded tables for storing the historyList by org and version.
 * 2. create new fields on $historyEntryQ1 to represent several virtual fields used by (1)
 */
Facade.TriggerRegistry.register("core.app.onLoad",function(behaviorFn,args) {
	var docDesign, historyDesign;
	var historyListByOrgField, historyListByVersionField;
	
	docDesign = Facade.DesignRegistry.get("$docSubmissionQ2");
	
	// add design fields for historyListByOrg and historyListByVersion; each of which are lists of $historyEntryQ1 entries
	historyListByOrgField = docDesign.data.addField("historyListByOrg");
	historyListByOrgField.setDesignType("$historyEntryQ1");
	historyListByVersionField = docDesign.data.addField("historyListByVersion");
	historyListByVersionField.setDesignType("$historyEntryQ1");
	
	// add history fields for latest version, etc. to be used by historyListByOrg and historyListByVersion
	historyDesign = Facade.DataRegistry.get("$historyEntryQ1");
	historyDesign.data.addField("latestVersionForOrg",historyDesign.data.getField("documentVersion"));
	historyDesign.data.addField("latestReqAcknowledgementForOrg",historyDesign.data.getField("reqAcknowledgement"));
	historyDesign.data.addField("latestSentByUserForOrg",historyDesign.data.getField("sentByUser"));
	historyDesign.data.addField("latestSendDateTimeForOrg",historyDesign.data.getField("sendDateTime"));
	historyDesign.data.addField("latestSendDateTimeForVersion",historyDesign.data.getField("sendDateTime"));
})

/*
 * for status lookup
 */
Facade.VirtualFieldRegistry.register("$docSubmissionQ2","localizedStatus",function(pathContext){
    var doc = Facade.PageRegistry.getPrimaryData();
	return Facade.Localization.localize("status." + doc.getData("status"));
})


/**
 * Page title
 */
Facade.Components.Docbar.setLabel(function(behaviorFn,args){
	var doc = Facade.PageRegistry.getPrimaryData();
	var name = (doc.getData("documentName") && doc.getData("documentName").length ? doc.getData("documentName") : doc.getData("documentID"));
	return Facade.Localization.localize("docSubmissionTitle")  + (name ? " " + name : "");
})
