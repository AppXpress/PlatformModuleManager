/**
 * Send History by Version - a section composed of:
 * 
 * 1. historyListByVersion - a virtual field on $docSubmissionQ2 that produces a version of historyList grouped by version.
 * 2. historyListByVersionTable - the table backed by historyListByVersion
 * 3. historyListSelectedVersionTable - the detail table for an version selected in historyListByVersionTable; backed by historyList and filtered by the selected org
 * 4. latestSendDateTimeForVersion - virtual field on $historyEntryQ1 displayed in historyListByVersionTable
 */
//a) historyListByVersion table is backed by a virtual field on $docSubmissionQ2
var byVersionCache = {}; // cache used by historyListByOrg
Facade.VirtualFieldRegistry.register("$docSubmissionQ2","historyListByVersion",function(pathContext){
	// get the real data
	var data = pathContext.getData();
	var historyList = data.historyList;
	
	// 1) byOrg
	var byVersion = [];
	var versionEntries, i, entryKey, versionEntry, cacheEntry;
	if (historyList && historyList.length) {
		versionEntries = {}; // map version+docName to an entry in historyList
		for (i = 0; i < historyList.length; i++) {
			if (historyList[i].documentID) {
				entryKey = historyList[i].documentID
				versionEntry = versionEntries[entryKey];
				if (!versionEntry) {
					// We first try to get an entry from byVersionCache.  The pupose of this cache is to avoid reconstructing a row object each call.
					// This reconstruction results in the row's $node being destroyed and this we immediately lose the seleciton-set record upon selection.
					cacheEntry = byVersionCache[entryKey];
					if (!cacheEntry) {
						cacheEntry = byVersionCache[entryKey] = {};
					}
					versionEntry = versionEntries[entryKey] = cacheEntry;
					byVersion.push(versionEntry);
					versionEntry.documentVersion = historyList[i].documentVersion;
					versionEntry.documentID = historyList[i].documentID;
					versionEntry.documentCategory = historyList[i].docCategoryLabel;
					versionEntry.documentName = historyList[i].documentName;
					versionEntry.reqAcknowledgement = historyList[i].reqAcknowledgement;
					versionEntry.sentByUser = historyList[i].sentByUser;
				}
			}
		}
	}
	
	return byVersion;
});
//b) make the selector buttons always visible (by default its only visible in edit mode)
var historyListByVersionTable = Facade.Components.Table.forName("historyListByVersionTable");
historyListByVersionTable.defaultSelection().setMask("NORMAL");
//c) historyListSelectedVersionTable - the table representing the detail rows for the selected version
var historyListSelectedVersionTable = Facade.Components.Table.forName("historyListSelectedVersionTable");
historyListSelectedVersionTable.setFilter(function(behaviorFn,filterArgs){
	var rowID = filterArgs.data.documentID;
	var selectedRow = behaviorFn.components.detail.getSelectionSet().getSelections()[0];
	return rowID && selectedRow && rowID == selectedRow.documentID;
});
//d) helper function - get history entry for the given version
function getHistoryEntryForVersion(documentID) {
	var historyList = Facade.PageRegistry.getPrimaryData().getData("historyList");
	var i;
	if (historyList) {
		for (i = 0; i < historyList.length; i++) {
			if (historyList[i].documentID == documentID) {
				return historyList[i];
			}
		}
	}
	return undefined;
}
//e) latest ack date
Facade.VirtualFieldRegistry.register("$historyEntryQ1","latestSendDateTimeForVersion",function(pathContext){
	var data = pathContext.getData();
	var latestEntry = getHistoryEntryForVersion(data.documentID);
	return latestEntry.sendDateTime;
});
