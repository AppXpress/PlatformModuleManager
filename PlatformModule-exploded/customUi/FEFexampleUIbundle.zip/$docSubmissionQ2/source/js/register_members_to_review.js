/**
 * Members to Review table
 */
// hide Add button (we use party lookup instead)
Facade.Components.Table.forPath("$sellerData2Q2","").addButton().setMask("HIDDEN");


/**
 * Members to Review section - it's mask should reflect that of reviewList.
 */
var membersToReviewSection = Facade.Components.Section.forName("membersToReviewSection");
membersToReviewSection.setMask(function(behaviorFn,args){
	var defaultMask = behaviorFn.resume();
	return defaultMask == "NORMAL" ? Facade.PageRegistry.getPathContext("reviewList").getMask() : defaultMask;
})
