/**
 * sellerGroupLookup - a named customization of the built-in core-party-lookup.
 * 
 * Seller groups are root objects defined for each org containing a list of seller parties.
 * 
 * We take the existing PartyLookup component and rework it so that its backing data is not the 
 * default party list but instead the members of a client-side data list "CurrentSellerGroup".
 * The lookup's resolveData is altered to query instead for the $listOfSellersQ1 objects and store this list in "SellerGroupList".
 * Furthermore, resolveData is where "CurrentSellerGroup" is produced.  See there for details.
 * The lookup dropdown is modified to have the contents of "SellerGroupList".
 * The lookup popover table is modified to show the members of the selected seller group.
 * In addition, the lookup popver contains an additional dropdown widget to filter by seller group.
 * The lookup Select button (renamed Add) is used to add the entire contents of the seller group selected in the lookup dropdown.
 */
var sellerGroupLookup = Facade.Components.PartyLookup.forName("sellerGroupLookup");

// Data resolution:
// Data resolution occurs in two stages, the first on the server, the second on the client.
// The final result is store in "CurrentSellerGroup" and the intermediate result in "SellerGroupList".
// First we get "SellerGroupList" from the server if it is not already resolved.
// Then we extract from it the seller group according to what is currently selected in the fiter dropdown.
// The latter is returned from the "SellerGroupList" and automatically gets stored in "CurrentSellerGroup".
// In addition, we perform a side task here - populating SellerGroupPicklist for use by the dropdown.
sellerGroupLookup.setDataIndex("CurrentSellerGroup");
sellerGroupLookup.setResolveData(function(behaviorFn,args){
	return Facade.Promises.combine([Facade.Resolver.design("$listOfSellersQ1"),
	                         Facade.Resolver.design("$sellerDataQ1"),
	                         Facade.Resolver.query("$listOfSellersQ1",{params: {status:"Active"}, slotName: "SellerGroupList"}, args && args.resolverOptions)])
	                         .then(function(results){
		var sellerGroupList = results[2];

		var sellerGroupPicklistItems = [], picklist;
		var lookupFilter, sellerList, sellerGroupId, selectedSellerGroup, sellerData;

		// register SellerGroupPicklist or update existing one
		_.each(sellerGroupList.getResults(),function(sellerList){
			sellerGroupPicklistItems.push({value:sellerList.getData("uid"), label:sellerList.getData("groupName")});
		})
		picklist = Facade.PicklistRegistry.get("SellerGroupPicklist");
		if (!picklist) {
			picklist = Facade.PicklistRegistry.create("SellerGroupPicklist",sellerGroupPicklistItems);
			Facade.PicklistRegistry.register("SellerGroupPicklist",picklist)
		} else {
			picklist.setList(sellerGroupPicklistItems);
		}
		
		// build the list for the current seller
		lookupFilter = Facade.DataRegistry.get("core.lookup.filter");
		sellerList = Facade.DataRegistry.createList();
		sellerGroupId = lookupFilter.getData("sellerGroupId");
		if (sellerGroupId != undefined) {
			selectedSellerGroup = _.find(sellerGroupList.getResults(),function(sellerGroup) {
				return sellerGroup.getData("uid") == sellerGroupId;
			});
			if (selectedSellerGroup) {
				_.each(selectedSellerGroup.getData("sellerList"),function(seller,index){
					var sellerData = Facade.DataRegistry.create({data:seller.sellerParty,type: "Party"});
					sellerList.pushResult(sellerData);

					// select all entries by default
					var sellerParty = selectedSellerGroup.getData("sellerList[" + index + "].sellerParty")
					if (!Facade.FunctionRegistry.evaluate("isInReviewList",sellerParty)) {
						Facade.Selections.select(behaviorFn.component.getSelectionSet().getName(),
							sellerData.getData(),undefined,true,true);
					}
				});
			}
		}
		return sellerList;
	});
})

// modify lookup dropdown contents and item labeler
var sellerGroupLookupDropdown = sellerGroupLookup.dropdown();
sellerGroupLookupDropdown.setItems(function(behaviorFn,args){
	// we first check if the groups have been resolved yet
	var sellerGroupList = Facade.DataRegistry.get("SellerGroupList");
	if (sellerGroupList) {
		return sellerGroupList.getResults();
	} else {
		// start loading the seller groups; upon resolution, the items will automatically be polled again
		behaviorFn.components.partyLookup.resolveLookup();
		return undefined;
	}
})
sellerGroupLookupDropdown.setItemLabel(function(behaviorFn,args){
	return args.item && args.item.getData("groupName") || "NO ITEM";
})

// Add button - when the Add button (renamed from Select) is clicked, add the members of the selected group in the lookup dropdown
var sellerGroupAddButton = sellerGroupLookup.selectButton();
sellerGroupAddButton.setLabelKey("lookup.add");
sellerGroupAddButton.setOnClick(function(behaviorFn,args){
	// add all members of the selected seller list
	var dropdown = behaviorFn.components.partyLookup.getDropdown();
	var selectedValue = dropdown && dropdown.getSelectedItem();
	var sellers, docSub, alreadyAdded;
	if (selectedValue != undefined) {
		sellers = selectedValue.getData("sellerList");
		if (sellers && sellers.length) {
			docSub = Facade.PageRegistry.getPrimaryData();
			alreadyAdded = "";
			_.each(sellers,function(seller,index){
				var newMember;
				
				// check if already exists
				var sellerParty = selectedValue.getData("sellerList[" + index + "].sellerParty");
				if (Facade.FunctionRegistry.evaluate("isInReviewList",sellerParty)) {
					alreadyAdded += "\n" + sellerParty.getName();
				} else {
					newMember = Facade.DataRegistry.createEmbedded({type: "$sellerData2Q2"});
					newMember.sellerOrgID = seller.sellerOrgID;
					newMember.sellerParty = seller.sellerParty;
					newMember.sellerGroupName = selectedValue.getData("groupName");
			                newMember.sellerGroupID = selectedValue.getData("uid");
					docSub.pushData("reviewList",newMember);
				}
			});
			if (alreadyAdded != "") {
				alert(Facade.Localization.localize("membersAlreadyInReviewList") + alreadyAdded);
			}
		} else {
			alert(Facade.Localization.localize("listHasNoMembers"))
		}
	}
})

// lookup button - when clicked, we clear the "CurrentSellerGroup" and init the popover filter to the dropdown's group
var sellerGroupLookupButton = sellerGroupLookup.lookupButton();
sellerGroupLookupButton.setOnClick(function(behaviorFn,args){
	var lookupFilter, dropdown, selectedValue;
	
	// before allowing the popover to show as usual, clear CurrentSellerGroup to ensure the data is 
	// repopulated by resolveData below with the currently selected group
	Facade.DataRegistry.deregister("CurrentSellerGroup");

	// next, set the filter to the currently selected group from the dropdown
	lookupFilter = Facade.DataRegistry.get("core.lookup.filter");
	dropdown = behaviorFn.components.partyLookup.getDropdown();
	selectedValue = dropdown && dropdown.getSelectedItem();
	if (selectedValue != undefined) {
		lookupFilter.setData("sellerGroupId",selectedValue.getData("uid"));
	} else {
		lookupFilter.removeData("sellerGroupId");
	}
	
	// continue opening the popover
	behaviorFn.resume();
})
   .setMask(function(behaviorFn,args){
			return "HIDDEN";
});

// lookup callback - upon final lookup, we add the parties as usual
sellerGroupLookup.setOnLookupFunction("onPartyLookup");

// highlight the rows and disable selection for orgs already added
sellerGroupLookup.lookupTable().row().setTableRowClassFunction("getPartyTableRowClass");
sellerGroupLookup.lookupTableMultipleSelection().setIsSelectableFunction("getPartyIsSelectable");

// reload button label
sellerGroupLookup.reloadDataButton().setLabelKey("sellerGroupLookup.reloadData");

// seller group dropdown - in contrast to the built-in lookup dropwn shown on the main form, 
// we define a second version of that dropdown in the lookup window itself
var sellerGroupPicklist = Facade.Components.Field.forKind("sellerGroupPicklist").picklist();
sellerGroupPicklist.setPickType("SellerGroupPicklist");
var sellerGroupPicklistDropdown = sellerGroupPicklist.dropdown();
sellerGroupPicklistDropdown.setLabelKey("sellerGroupLookup.sellerGroupPicklistDropdown.selectSeller");

// upon changing the dropdown item, we clear "CurrentSellerGroup" and resolve again
sellerGroupPicklistDropdown.setOnSelect(function(behaviorFn,args){
	Facade.DataRegistry.deregister("CurrentSellerGroup");
	behaviorFn.components.partyLookup.resolveLookup();
	behaviorFn.resume();
})

// add custom form content to the lookup popoover (see SellerGroupLookupForm.html)
sellerGroupLookup.lookupForm().setTemplate("SellerGroupLookupForm");
