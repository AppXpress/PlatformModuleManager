/**
 * Send History section - it's mask should reflect that of historyList.
 */
var sendHistorySection = Facade.Components.Section.forName("sendHistorySection");
sendHistorySection.setMask(function(behaviorFn,args){
	return Facade.PageRegistry.getPathContext("historyList").getMask();
})
