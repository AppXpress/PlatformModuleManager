/**
 * Localization Keys.  This is a temporary solution until we offer server-side localization.
 */
var localizationKeys = {
	"acknowledgement": "Acknowledgement",
	"acknowledgementFor": "Acknowledgement for",
	"attachment": "Attachment",
	"buyerLicensee": "Submitted By",
	"documentCategoryList": "Document Category",
	"status.NewVersionAvailable": "Never Reviewed - Newer Version Available",
	"status.ReviewedButNewerVersionAvail": "Reviewed - Newer Version Available",
	"localizedStatus": "Status",
	"docCategoryLabel": "Document Category",
	"attachments.attachmentName": "File Name",
	"attachments.attachmentSize": "Content Size",
	"attachments.attachmentModifyTimestamp": "Last Modified",
	"attachments.attachmentDescription": "Description",
	"attachmentFile": "File Name"

};
Facade.FunctionRegistry.register("core.localization.localize",function(behaviorFn,args){
	var s = localizationKeys[args.key];
	if (s != undefined) {
		return s;
	} else {
		return behaviorFn.resume();
	}
});

