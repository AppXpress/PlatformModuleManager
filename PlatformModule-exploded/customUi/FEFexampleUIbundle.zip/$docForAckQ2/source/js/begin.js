// field attachName should be a link
var attachmentLink = Facade.Components.Link.forKind("attachmentLink");
attachmentLink.setLabel(function(behaviorFn,args){
	var attachment = behaviorFn.components.tableRow.getPathContext().getData();
	return attachment.attachmentName;
})
attachmentLink.setUrl(function(behaviorFn,args){
	var attachment = behaviorFn.components.tableRow.getPathContext().getData();
    var escapedName = escape(attachment.attachmentName);
    return Facade.UrlBuilder.build("/DynamicContentServlet/" + escapedName, {
        producer: "FileAttachmentMediaProducer",
        mediaType: "Media",
        mediaId: attachment.attachmentUID,
        filename: escapedName
    })
})

// we dont want an edit or save button on this page, just workflow actions
Facade.Components.Docbar.editButton().setMask("HIDDEN");
Facade.Components.Docbar.saveButton().setMask("HIDDEN");
Facade.Components.Docbar.actionsButton().setMask(function(behaviorFn,args){
			// hide the drop-down when there are 2 or less actions
			var actions = behaviorFn.components.docbar.getActions();
			return actions && actions.length > behaviorFn.components.docbar.getMaxPromotedActions() &&
                !Facade.PageRegistry.inEditMode() ? "NORMAL" : "HIDDEN";
		});
		
/*
 * for status lookup
 */
Facade.VirtualFieldRegistry.register("$docForAckQ2","localizedStatus",function(pathContext){
    var doc = Facade.PageRegistry.getPrimaryData();
	return Facade.Localization.localize("status." + doc.getData("status"));
})

/**
 * Page title
 */
Facade.Components.Docbar.setLabel(function(behaviorFn,args){
	var ack = Facade.PageRegistry.getPrimaryData();
	var name = (ack.getData("documentName") && ack.getData("documentName").length ? ack.getData("documentName") : ack.getData("documentID"));
	return Facade.Localization.localize("acknowledgementFor")  + (name ? " " + name : "");
})

/**
 * Define startingPage.
 * The first page of the app should be the LicenseePicker if the doc is new and more than one choice is available.
 */
Facade.FunctionRegistry.register("core.page.startingPage",function(behaviorFn, args) {
	var doc = Facade.PageRegistry.getPrimaryData();
	if (false) {
		return Facade.PageRegistry.get("AcknowledgementForBuyer");
	}
	return behaviorFn.resume();
});


