/**
 * Localization Keys.  This is a temporary solution until we offer server-side localization.
 */
var localizationKeys = {
    "sellerGroupSection": "Group Identification",
	"sellerGroupSectionFor": "Seller Group Details for",
	"listOfSellers": "List of Sellers",
	"sellersInGroup": "Sellers In This Group",
	"addSeller": "Add Seller",
	"buyerLicenseeParty": "Buyer",
        "noLicensees": "Module has no licensee",
        "cannotCreate": "Cannot create a list of Sellers.",
        "chooseLicenseeSection": "Choose a Licensee",
        "licenseeLookup.label": "Which organization?",
		"modifyList":"Open to Modify",
		"thisGroupIsIn": "This vendor group is used in the following documents:",
		"thisGroupIsIn2": "You may want to modify those documents' review lists if you have made changes here."
};
Facade.FunctionRegistry.register("core.localization.localize",function(behaviorFn,args){
	var s = localizationKeys[args.key];
	if (s != undefined) {
		return s;
	} else {
		return behaviorFn.resume();
	}
});
