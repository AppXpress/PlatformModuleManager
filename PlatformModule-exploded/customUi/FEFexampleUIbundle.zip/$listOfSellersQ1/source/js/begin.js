/**
 * initialSaveInProgress - a flag we use to track whether we are saving the doc for the first time.
 * 
 * It's usefulness is apparent below when we intercept onSaveSuccess and disable the ui success message in this case.
 */
var initialSaveInProgress = false;


/**
 * Helper method - getLicensees - the available licensees for the document.
 */
function getLicensees() {
    var design = Facade.DataRegistry.get("$listOfSellersQ1");
    if ( design ) {
        return design.getData("licensee.orgId");
    }
    return [];
}


/**
 * Helper method - setListOfSellersLicensee - assign the given licensee to the document and save it; then forward to the main screen.
 */
function setListOfSellersLicensee(licensee) {
    var doc = Facade.PageRegistry.getPrimaryData();
    doc.setData("buyerLicenseeParty", {
        memberId: licensee
    });
    initialSaveInProgress = true;
    return Facade.PageRegistry.save().then(function(){
        initialSaveInProgress = false;
        Facade.PageRegistry.setCurrent("ListOfSellers");
    });
};

/**
 * Define startingPage.
 * The first page of the app should be the LicenseePicker if the doc is new and more than one choice is available.
 */
Facade.FunctionRegistry.register("core.page.startingPage",function(behaviorFn, args) {
	var doc = Facade.PageRegistry.getPrimaryData(),
    	licensees = getLicensees();
	if (doc.isNew && licensees && licensees.length > 1) {
		return Facade.PageRegistry.get("LicenseePickerForSellerList");
	}
	return behaviorFn.resume();
});


/**
 * On app load, inspect the licensees available if this is a new doc:
 * 1. if we find there are no licensees available, report an error condition.
 * 2. if there is one available, assign it
 * 3. if there is more than one available, take no action: above the starting page will be set in this condition.
 * 
 * In case 2, we return the promise for the save operation.  The result is that the UI will not load until that completes.
 */
Facade.TriggerRegistry.register("core.app.onLoad",function() {
	var doc = Facade.PageRegistry.getPrimaryData(),
        licensees = getLicensees();

	if (doc.isNew) {
        if ( !licensees || !licensees.length ) {
            Facade.MessageLog.addEntry("noLicensees");
            Facade.MessageLog.addMessage(Facade.MessageLog.createError("cannotCreate"));
        } else if (licensees.length === 1) { // just set buyer licensee to one licensee available and save
            return setListOfSellersLicensee(licensees[0]);
        }
	} 
});


/**
 * Licensee Org Lookup - when user makes a selection, set the licensee on the doc.
 */
Facade.FunctionRegistry.register("onLicenseeSelected",function(behaviorFn,args){
	// upon selection, set the document's licensee and forward to the main page
	var selectedOrg = behaviorFn.components.lookup.getSelectionSet().getSelections()[0];
	setListOfSellersLicensee(Facade.Decorator.Organization(selectedOrg).getOrganizationId());
})

/**
 * We want to suppress the "Saved successfully" alert when the page first loads with a newly created object (see core.page.onLoad above)
 */
Facade.FunctionRegistry.register("core.page.onSaveSuccess",function(behaviorFn,args) {
	if (!initialSaveInProgress) {
		behaviorFn.resume();
	} 
});

Facade.Components.Docbar.editButton().setMask(function(behaviorFn,args){
    var sellerListStatus = Facade.PageRegistry.getPrimaryData().getData("status");
	if (sellerListStatus == "Active") {
		return "HIDDEN";
	}
	return Facade.PageRegistry.inEditMode() ? "HIDDEN" : "NORMAL"
});


////// 1) set up the party lookup
var sellerLookup = Facade.Components.PartyLookup.forName("sellerLookup");
sellerLookup.setFilter(function(behaviorFn,filterArgs){
	var roles = filterArgs.data.getRoles();
	return roles && roles.indexOf("Seller") != -1;
});
sellerLookup.lookupTable().setFilter(function(behaviorFn,filterArgs){
	var roles = filterArgs.data.getRoles();
	return roles && roles.indexOf("Seller") != -1;
});

//a) lookup callback
function isInSellerList(party) {
    var primaryData = Facade.PageRegistry.getPrimaryData();
	var sellerList = primaryData.getData("sellerList");
	if (sellerList) {
		for (var i = 0; i < sellerList.length; i++) {
            var sellerParty = primaryData.getData("sellerList[" + i + "].sellerParty")
			if (sellerParty && party.equals(sellerParty)) {
				return true;
			}
		}
	}
}
sellerLookup.setOnLookup(function(behaviorFn,args){
	var parties = behaviorFn.components.partyLookup.getSelectionSet().getSelections();
	var listOfSellers = Facade.PageRegistry.getPrimaryData();
	for (var i = 0; i < parties.length; i++) {
		// check if already exists
		if (isInSellerList(parties[i])) {
			alert("Member already in seller list: " + parties[i].getLookupName());
		} else {
			var newMember = Facade.FunctionRegistry.execute("core.data.createNode",{type: "$sellerDataQ1"});
			newMember.sellerOrgID = parties[i].getOrganizationId();
			newMember.sellerParty = parties[i].duplicate();
			listOfSellers.pushData("sellerList",newMember);
            behaviorFn.components.partyLookup.getDropdown().setSelectedItem(undefined);
		}
	}
})
// b) highlight the rows and disable selection for orgs already added
sellerLookup.lookupTable().row().setTableRowClass(function(behaviorFn,args){
	if (isInSellerList(behaviorFn.components.tableRow.getPathContext().getData())) {
		return behaviorFn.resume() + " selected_party"; // see app.css
	} else {
		return behaviorFn.resume();
	}
});
sellerLookup.lookupTableMultipleSelection().setIsSelectable(function(behaviorFn,args){
	if (isInSellerList(behaviorFn.components.tableRow.getPathContext().getData())) {
		return false;
	} else {
		return behaviorFn.resume();
	}
});
// c) select button label
sellerLookup.selectButton().setLabel("Add");

/////// 2) Sellers table
//a) hide Add button (we use party lookup instead)
Facade.Components.Table.forName("sellerList").addButton().setMask("HIDDEN");


/**
 * Page title
 */
Facade.Components.Docbar.setLabel(function(behaviorFn,args){
	var listOfSellers = Facade.PageRegistry.getPrimaryData();
	var name = (listOfSellers.getData("groupName") && listOfSellers.getData("groupName").length ? listOfSellers.getData("groupName") : listOfSellers.getData("uid"));
	return Facade.Localization.localize("sellerGroupSectionFor") + (name ? " " + name : "");
})

//put up the documents that contain this group
			
Facade.FunctionRegistry.register("core.page.onTransitionSuccess",function(behaviorFn,args) {
	//console.log(args.action);
	if ( args.action === "wf_approve" ) {
		var listOfSellersDoc = Facade.PageRegistry.getPrimaryData();
		var groupID = listOfSellersDoc.getData("uid");
		//console.log(groupID);
		Facade.Resolver.query("$docSubmissionQ2", { params: {oql:"reviewList.sellerGroupID ='" + groupID + "'"}, slotName: "docsForThisGroup"}).then(function(result) {
			var dataFromObject = Facade.DataRegistry.get("docsForThisGroup");
			//console.log(dataFromObject);
			var docNames = "";
			if (dataFromObject.getData().length > 0) {
				for (var i = 0; i < dataFromObject._results.length; i++) {
					docNames += "\n" + dataFromObject._results[i].data.documentName;
				}
				alert(Facade.Localization.localize("thisGroupIsIn") + "\n" + docNames + "\n\n" + Facade.Localization.localize("thisGroupIsIn2"));
			}
		})
	}
   // any other post-transition stuff you want to do
   behaviorFn.resume(); // to preserve that default info alert message
});
